# coding: utf-8
from university.models import News
News.objects.create(title="Первая новость", slug="pervaya-novost", content="Содержание новости")
objects.create(title="Вторая новость", slug="vtoraya-novost", content="Содержание новости")
News.objects.create(title="Вторая новость", slug="vtoraya-novost", content="Содержание новости")
